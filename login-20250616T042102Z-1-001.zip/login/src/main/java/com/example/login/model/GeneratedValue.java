package com.example.login.model;

public @interface GeneratedValue {

}
